package com.example.railgun;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class RailgunMod implements ModInitializer {
    public static final String MOD_ID = "railgun";
    public static final Item RAILGUN = Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "railgun"),
            new RailgunItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(RailShotPayload.ID, RailShotPayload.CODEC);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> e.add(RAILGUN));
    }
}
