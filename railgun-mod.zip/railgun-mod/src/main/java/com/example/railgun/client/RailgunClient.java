package com.example.railgun.client;

import com.example.railgun.RailShotPayload;
import com.example.railgun.RailgunMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.item.ModelPredicateProviderRegistry;
import net.minecraft.util.Identifier;

public class RailgunClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(RailShotPayload.ID,
                (payload, ctx) -> RailgunFX.onShot(payload, ctx.client()));
        ClientTickEvents.END_CLIENT_TICK.register(RailgunFX::tick);
        HudRenderCallback.EVENT.register((ctx, tc) -> RailgunFX.render(ctx, tc.getTickDelta(false)));

        // drives the 4-stage charge model (see assets/railgun/models/item/railgun.json)
        ModelPredicateProviderRegistry.register(RailgunMod.RAILGUN, Identifier.of(RailgunMod.MOD_ID, "charge"),
                (stack, world, entity, seed) -> {
                    if (entity == null || !entity.isUsingItem() || !entity.getActiveItem().isOf(RailgunMod.RAILGUN))
                        return 0f;
                    return Math.min(entity.getItemUseTime() / 20f, 1f);
                });
    }
}
