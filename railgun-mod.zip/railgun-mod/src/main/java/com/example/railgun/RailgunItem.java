package com.example.railgun;

import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Optional;

public class RailgunItem extends Item {
    public static final int CHARGE_TICKS = 20;
    public static final double RANGE = 128;
    public static final float DAMAGE = 40f;   // 20 hearts
    public static final int COOLDOWN = 40;

    public RailgunItem(Settings settings) { super(settings); }

    @Override public UseAction getUseAction(ItemStack stack) { return UseAction.BOW; }
    @Override public int getMaxUseTime(ItemStack stack) { return 72000; }

    private static boolean hasAmmo(PlayerEntity p) {
        return p.isCreative() || p.getInventory().count(Items.IRON_INGOT) > 0;
    }

    private static void consumeAmmo(PlayerEntity p) {
        if (p.isCreative()) return;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(Items.IRON_INGOT)) { s.decrement(1); return; }
        }
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!hasAmmo(player)) {
            if (!world.isClient)
                world.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.BLOCK_DISPENSER_FAIL, SoundCategory.PLAYERS, 1f, 1.4f);
            return TypedActionResult.fail(stack);
        }
        player.setCurrentHand(hand);
        if (!world.isClient)
            world.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.PLAYERS, 1.2f, 1.9f);
        return TypedActionResult.consume(stack);
    }

    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        if (world.isClient || !(user instanceof ServerPlayerEntity p)) return;
        int charged = getMaxUseTime(stack) - remainingUseTicks;
        if (charged < CHARGE_TICKS || !hasAmmo(p)) return;
        fire(p);
        consumeAmmo(p);
        p.getItemCooldownManager().set(this, COOLDOWN);
    }

    private void fire(ServerPlayerEntity p) {
        ServerWorld sw = p.getServerWorld();
        Vec3d eye = p.getEyePos();
        Vec3d dir = p.getRotationVec(1f);
        Vec3d far = eye.add(dir.multiply(RANGE));

        BlockHitResult bhr = sw.raycast(new RaycastContext(eye, far,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        Vec3d end = bhr.getType() == HitResult.Type.MISS ? far : bhr.getPos();

        boolean hit = false;
        Box box = new Box(eye, end).expand(1.5);
        for (Entity e : sw.getOtherEntities(p, box, x -> x instanceof LivingEntity le && le.isAlive())) {
            Optional<Vec3d> r = e.getBoundingBox().expand(0.4).raycast(eye, end);
            if (r.isEmpty()) continue;
            e.damage(sw.getDamageSources().playerAttack(p), DAMAGE);
            e.addVelocity(dir.x * 3.0, dir.y * 3.0 + 0.6, dir.z * 3.0);
            e.velocityModified = true;
            e.setOnFireFor(4);
            hit = true;
        }

        // visuals are drawn from just in front of the muzzle
        Vec3d muzzle = eye.add(dir.multiply(1.2)).add(0, -0.2, 0);
        RailShotPayload payload = new RailShotPayload(p.getId(), muzzle, end, hit);
        for (ServerPlayerEntity other : PlayerLookup.around(sw, p.getPos(), 192))
            ServerPlayNetworking.send(other, payload);

        // sound stack
        play(sw, eye, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 3f, 1.3f);
        play(sw, eye, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 2.0f);
        play(sw, end, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 3f, 0.7f);
        play(sw, end, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2f, 0.6f);

        // recoil
        p.addVelocity(-dir.x * 0.6, -dir.y * 0.3, -dir.z * 0.6);
        p.velocityModified = true;
        p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
    }

    private static void play(ServerWorld w, Vec3d pos, SoundEvent s, float vol, float pitch) {
        w.playSound(null, pos.x, pos.y, pos.z, s, SoundCategory.PLAYERS, vol, pitch);
    }
}
